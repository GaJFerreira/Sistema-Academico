import React from 'react';
import { Navbar, Nav, Container } from 'react-bootstrap';
import '../estilos/EstiloGeral.css'
import logo from '../assets/logo.png';

const Header = () => (
  <Navbar bg="dark" variant="dark" expand="lg">
    <Container>
    <a class="navbar-brand" href="#">
      <img src={logo} alt="Logo" width="30" height="24" />
      <Navbar.Brand href="/">Sistema Universitário</Navbar.Brand>
       
    </a>    
     
    </Container>
  </Navbar>
);

export default Header;
