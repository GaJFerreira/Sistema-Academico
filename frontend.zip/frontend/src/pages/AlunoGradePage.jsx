"use client"

import { useState, useEffect } from "react"
import { Container, Table, Card, Button, Modal, Form, Badge, Row, Col, Alert } from "react-bootstrap"
import { useNavigate } from "react-router-dom"
import { buscarDisciplinasAluno, listarDisciplinas, matricularDisciplina } from "../services/disciplinaService"

function AlunoGradePage() {
  const [disciplinasAluno, setDisciplinasAluno] = useState([])
  const [disciplinasDisponiveis, setDisciplinasDisponiveis] = useState([])
  const [disciplinasFiltradas, setDisciplinasFiltradas] = useState([])
  const [disciplinasSelecionadas, setDisciplinasSelecionadas] = useState([])
  const [showModal, setShowModal] = useState(false)
  const [filtro, setFiltro] = useState("")
  const [departamentoFiltro, setDepartamentoFiltro] = useState("")
  const [departamentos, setDepartamentos] = useState([])
  const [mensagem, setMensagem] = useState({ texto: "", tipo: "" })
  const navigate = useNavigate()

  // Simular ID do aluno logado
  const alunoId = 1

  useEffect(() => {
    // Carregar disciplinas do aluno
    buscarDisciplinasAluno(alunoId)
      .then((data) => {
        setDisciplinasAluno(data)
      })
      .catch((err) => {
        console.error("Erro ao buscar disciplinas do aluno:", err)
        setMensagem({
          texto: "Erro ao carregar disciplinas do aluno. Tente novamente mais tarde.",
          tipo: "danger",
        })
      })

    // Carregar todas as disciplinas disponíveis
    listarDisciplinas()
      .then((data) => {
        setDisciplinasDisponiveis(data)
        setDisciplinasFiltradas(data)

        // Extrair departamentos únicos para o filtro
        const deps = [...new Set(data.map((d) => d.departamento))].sort()
        setDepartamentos(deps)
      })
      .catch((err) => {
        console.error("Erro ao listar disciplinas:", err)
        setMensagem({
          texto: "Erro ao carregar disciplinas disponíveis. Tente novamente mais tarde.",
          tipo: "danger",
        })
      })
  }, [alunoId])

  // Filtrar disciplinas disponíveis
  useEffect(() => {
    let resultado = disciplinasDisponiveis

    // Filtrar por nome ou código
    if (filtro) {
      resultado = resultado.filter(
        (d) =>
          d.nome.toLowerCase().includes(filtro.toLowerCase()) || d.codigo.toLowerCase().includes(filtro.toLowerCase()),
      )
    }

    // Filtrar por departamento
    if (departamentoFiltro) {
      resultado = resultado.filter((d) => d.departamento === departamentoFiltro)
    }

    // Remover disciplinas que o aluno já está matriculado
    const disciplinasMatriculadasIds = disciplinasAluno.map((d) => d.disciplinaId)
    resultado = resultado.filter((d) => !disciplinasMatriculadasIds.includes(d.id))

    setDisciplinasFiltradas(resultado)
  }, [filtro, departamentoFiltro, disciplinasDisponiveis, disciplinasAluno])

  const handleToggleDisciplina = (disciplinaId) => {
    if (disciplinasSelecionadas.includes(disciplinaId)) {
      setDisciplinasSelecionadas(disciplinasSelecionadas.filter((id) => id !== disciplinaId))
    } else {
      setDisciplinasSelecionadas([...disciplinasSelecionadas, disciplinaId])
    }
  }

  const handleMatricular = async () => {
    if (disciplinasSelecionadas.length === 0) {
      setMensagem({
        texto: "Selecione pelo menos uma disciplina para se matricular.",
        tipo: "warning",
      })
      return
    }

    try {
      // Em um cenário real, você enviaria todas as disciplinas selecionadas para o backend
      const promises = disciplinasSelecionadas.map((disciplinaId) => matricularDisciplina(alunoId, disciplinaId))
      await Promise.all(promises)

      setMensagem({
        texto: "Matrícula realizada com sucesso!",
        tipo: "success",
      })

      // Atualizar a lista de disciplinas do aluno
      const novasDisciplinas = await buscarDisciplinasAluno(alunoId)
      setDisciplinasAluno(novasDisciplinas)

      // Limpar seleções e fechar modal
      setDisciplinasSelecionadas([])
      setShowModal(false)
    } catch (error) {
      console.error("Erro ao matricular:", error)
      setMensagem({
        texto: "Erro ao realizar matrícula. Tente novamente mais tarde.",
        tipo: "danger",
      })
    }
  }

  const getStatusBadge = (status) => {
    switch (status) {
      case "Em Andamento":
        return <Badge bg="primary">{status}</Badge>
      case "Concluída":
        return <Badge bg="success">{status}</Badge>
      case "Reprovado":
        return <Badge bg="danger">{status}</Badge>
      case "Trancada":
        return <Badge bg="warning">{status}</Badge>
      default:
        return <Badge bg="secondary">{status}</Badge>
    }
  }

  return (
    <Container className="mt-5 mb-5">
      <h1 className="text-center mb-4">Grade Curricular</h1>

      {mensagem.texto && (
        <Alert variant={mensagem.tipo} dismissible onClose={() => setMensagem({ texto: "", tipo: "" })}>
          {mensagem.texto}
        </Alert>
      )}

      <Card className="shadow mb-4">
        <Card.Header className="bg-primary text-white">
          <div className="d-flex justify-content-between align-items-center">
            <h3 className="mb-0">Minhas Disciplinas</h3>
            <Button variant="light" onClick={() => setShowModal(true)}>
              Adicionar Disciplinas
            </Button>
          </div>
        </Card.Header>
        <Card.Body>
          {disciplinasAluno.length === 0 ? (
            <Alert variant="info">
              Você ainda não está matriculado em nenhuma disciplina. Clique em "Adicionar Disciplinas" para começar.
            </Alert>
          ) : (
            <Table striped bordered hover responsive>
              <thead className="table-dark">
                <tr>
                  <th>Código</th>
                  <th>Disciplina</th>
                  <th>Créditos</th>
                  <th>Carga Horária</th>
                  <th>Semestre</th>
                  <th>Status</th>
                  <th>Nota</th>
                </tr>
              </thead>
              <tbody>
                {disciplinasAluno.map((item) => (
                  <tr key={item.id}>
                    <td>{item.disciplina.codigo}</td>
                    <td>{item.disciplina.nome}</td>
                    <td>{item.disciplina.creditos}</td>
                    <td>{item.disciplina.cargaHoraria}h</td>
                    <td>{item.semestre}</td>
                    <td>{getStatusBadge(item.status)}</td>
                    <td>{item.nota !== null ? item.nota.toFixed(1) : "-"}</td>
                  </tr>
                ))}
              </tbody>
            </Table>
          )}
        </Card.Body>
      </Card>

      <div className="d-flex justify-content-between mt-4">
        <Button variant="secondary" onClick={() => navigate("/aluno")}>
          Voltar
        </Button>
      </div>

      {/* Modal para adicionar disciplinas */}
      <Modal show={showModal} onHide={() => setShowModal(false)} size="lg">
        <Modal.Header closeButton className="bg-primary text-white">
          <Modal.Title>Adicionar Disciplinas</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Row className="mb-3">
            <Col md={6}>
              <Form.Group>
                <Form.Label>Buscar por nome ou código</Form.Label>
                <Form.Control
                  type="text"
                  placeholder="Digite para buscar..."
                  value={filtro}
                  onChange={(e) => setFiltro(e.target.value)}
                />
              </Form.Group>
            </Col>
            <Col md={6}>
              <Form.Group>
                <Form.Label>Filtrar por departamento</Form.Label>
                <Form.Select value={departamentoFiltro} onChange={(e) => setDepartamentoFiltro(e.target.value)}>
                  <option value="">Todos os departamentos</option>
                  {departamentos.map((dep) => (
                    <option key={dep} value={dep}>
                      {dep}
                    </option>
                  ))}
                </Form.Select>
              </Form.Group>
            </Col>
          </Row>

          {disciplinasFiltradas.length === 0 ? (
            <Alert variant="info">Nenhuma disciplina disponível com os filtros selecionados.</Alert>
          ) : (
            <Table striped bordered hover>
              <thead className="table-dark">
                <tr>
                  <th style={{ width: "50px" }}></th>
                  <th>Código</th>
                  <th>Disciplina</th>
                  <th>Créditos</th>
                  <th>Departamento</th>
                </tr>
              </thead>
              <tbody>
                {disciplinasFiltradas.map((disciplina) => (
                  <tr key={disciplina.id}>
                    <td className="text-center">
                      <Form.Check
                        type="checkbox"
                        checked={disciplinasSelecionadas.includes(disciplina.id)}
                        onChange={() => handleToggleDisciplina(disciplina.id)}
                      />
                    </td>
                    <td>{disciplina.codigo}</td>
                    <td>{disciplina.nome}</td>
                    <td>{disciplina.creditos}</td>
                    <td>{disciplina.departamento}</td>
                  </tr>
                ))}
              </tbody>
            </Table>
          )}
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowModal(false)}>
            Cancelar
          </Button>
          <Button variant="primary" onClick={handleMatricular} disabled={disciplinasSelecionadas.length === 0}>
            Matricular ({disciplinasSelecionadas.length} selecionada{disciplinasSelecionadas.length !== 1 ? "s" : ""})
          </Button>
        </Modal.Footer>
      </Modal>
    </Container>
  )
}

export default AlunoGradePage
