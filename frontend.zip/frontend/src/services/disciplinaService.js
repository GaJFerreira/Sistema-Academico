const API_URL = "http://localhost:8080/api/disciplinas"

// Listar todas as disciplinas disponíveis
export async function listarDisciplinas() {
  try {
    // Simulando dados de API - em produção, substituir por chamada real
    return [
      { id: 1, codigo: "MAT101", nome: "Cálculo I", creditos: 4, cargaHoraria: 60, departamento: "Matemática" },
      { id: 2, codigo: "FIS102", nome: "Física I", creditos: 4, cargaHoraria: 60, departamento: "Física" },
      { id: 3, codigo: "PROG103", nome: "Programação I", creditos: 4, cargaHoraria: 60, departamento: "Computação" },
      { id: 4, codigo: "ALG104", nome: "Algoritmos", creditos: 4, cargaHoraria: 60, departamento: "Computação" },
      { id: 5, codigo: "BD105", nome: "Banco de Dados", creditos: 4, cargaHoraria: 60, departamento: "Computação" },
      {
        id: 6,
        codigo: "ENG106",
        nome: "Engenharia de Software",
        creditos: 4,
        cargaHoraria: 60,
        departamento: "Computação",
      },
      {
        id: 7,
        codigo: "REDES107",
        nome: "Redes de Computadores",
        creditos: 4,
        cargaHoraria: 60,
        departamento: "Computação",
      },
      {
        id: 8,
        codigo: "SO108",
        nome: "Sistemas Operacionais",
        creditos: 4,
        cargaHoraria: 60,
        departamento: "Computação",
      },
    ]
  } catch (error) {
    console.error("Erro ao listar disciplinas:", error)
    throw error
  }
}

// Buscar disciplinas do aluno
export async function buscarDisciplinasAluno(alunoId) {
  try {
    // Simulando dados de API - em produção, substituir por chamada real
    return [
      {
        id: 1,
        disciplinaId: 1,
        disciplina: {
          id: 1,
          codigo: "MAT101",
          nome: "Cálculo I",
          creditos: 4,
          cargaHoraria: 60,
        },
        status: "Em Andamento",
        nota: null,
        semestre: "2025.1",
      },
      {
        id: 2,
        disciplinaId: 3,
        disciplina: {
          id: 3,
          codigo: "PROG103",
          nome: "Programação I",
          creditos: 4,
          cargaHoraria: 60,
        },
        status: "Concluída",
        nota: 8.5,
        semestre: "2024.2",
      },
      {
        id: 3,
        disciplinaId: 5,
        disciplina: {
          id: 5,
          codigo: "BD105",
          nome: "Banco de Dados",
          creditos: 4,
          cargaHoraria: 60,
        },
        status: "Em Andamento",
        nota: null,
        semestre: "2025.1",
      },
    ]
  } catch (error) {
    console.error("Erro ao buscar disciplinas do aluno:", error)
    throw error
  }
}

// Matricular aluno em disciplina
export async function matricularDisciplina(alunoId, disciplinaId) {
  try {
    // Simulando chamada de API - em produção, substituir por chamada real
    console.log(`Matriculando aluno ${alunoId} na disciplina ${disciplinaId}`)
    return { success: true, message: "Matrícula realizada com sucesso" }
  } catch (error) {
    console.error("Erro ao matricular em disciplina:", error)
    throw error
  }
}
