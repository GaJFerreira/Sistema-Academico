const API_URL = "http://localhost:8080/api/alunos";

export async function listarAlunos() {
  const res = await fetch(API_URL);
  if (!res.ok) throw new Error("Erro ao listar alunos");
  return res.json();
}
