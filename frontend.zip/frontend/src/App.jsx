import { Routes, Route } from "react-router-dom"
import Layout from "./components/Layout"
import HomePage from "./pages/Home"
import AlunoPage from "./pages/AlunoPage"
import AlunoCadastroPage from "./pages/AlunoCadastroPage"
import AlunoLoginPage from "./pages/AlunoLoginPage"
import AlunoGradePage from "./pages/AlunoGradePage"

function App() {
  return (
    <Layout>
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/aluno" element={<AlunoPage />} />
        <Route path="/aluno/cadastro" element={<AlunoCadastroPage />} />
        <Route path="/aluno/login" element={<AlunoLoginPage />} />
        <Route path="/aluno/grade" element={<AlunoGradePage />} />
        <Route
          path="/administrador"
          element={
            <div className="container mt-5">
              <h2>Área do Administrador</h2>
            </div>
          }
        />
      </Routes>
    </Layout>
  )
}

export default App
